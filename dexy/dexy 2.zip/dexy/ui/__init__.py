"""
UI Package for Dexy Meeting Agent
Contains Streamlit components and web interface
"""

__version__ = "1.0.0"
__author__ = "Dexy Meeting Agent"